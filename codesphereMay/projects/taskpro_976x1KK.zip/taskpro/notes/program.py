


product={"title":"abc","brand":"samsung"}

product_price=product.get("price",0)

print(product_price)#None